package org.mdw.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext appContext= new ClassPathXmlApplicationContext("demo-beans.xml");
		SocieteDevLogiciel societeDev=(SocieteDevLogiciel) appContext.getBean("societeDevLogiciel");
		System.out.println("hi its " + societeDev.getDeveloppeur().getNom()+" with " + societeDev.getDeveloppeur().getAnneeExperience()+" years of experience");
		
		System.out.println("hi its the chef " + societeDev.getChefDeveloppeur().getNom()+" with " + societeDev.getChefDeveloppeur().getAnneeExperience()+" years of experience");
		
		

	}

}
