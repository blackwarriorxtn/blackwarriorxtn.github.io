package org.mdw.demo;

public class SocieteDevLogiciel {
	
	private Developpeur developpeur ;
	private Developpeur chefDeveloppeur ;
	/**
	 * @return the developpeur
	 */
	public Developpeur getDeveloppeur() {
		return developpeur;
	}
	/**
	 * @param developpeur the developpeur to set
	 */
	public void setDeveloppeur(Developpeur developpeur) {
		this.developpeur = developpeur;
	}
	/**
	 * @return the chefDeveloppeur
	 */
	public Developpeur getChefDeveloppeur() {
		return chefDeveloppeur;
	}
	/**
	 * @param chefDeveloppeur the chefDeveloppeur to set
	 */
	public void setChefDeveloppeur(Developpeur chefDeveloppeur) {
		this.chefDeveloppeur = chefDeveloppeur;
	}

	

	} 

