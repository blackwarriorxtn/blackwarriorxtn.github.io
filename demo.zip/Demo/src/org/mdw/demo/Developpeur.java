package org.mdw.demo;

public class Developpeur {

	private String nom ; 
	private int anneeExperience;
	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	/**
	 * @return the anneeExperience
	 */
	public int getAnneeExperience() {
		return anneeExperience;
	}
	/**
	 * @param anneeExperience the anneeExperience to set
	 */
	public void setAnneeExperience(int anneeExperience) {
		this.anneeExperience = anneeExperience;
	}
	

}


